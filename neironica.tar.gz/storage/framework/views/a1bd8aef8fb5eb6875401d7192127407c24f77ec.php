<?php echo e($slot); ?>

<?php /**PATH /home/arudamanov/domains/neironica.com/public_html/tools/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>