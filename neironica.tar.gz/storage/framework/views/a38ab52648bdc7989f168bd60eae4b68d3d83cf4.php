<?php $__env->startSection('content'); ?>

<section id="maze">
  <div class="container">
    <h3 class="tools-title border-c">Генератор лабиринтов</h3>
  </div>
  <div class="jumbotron jumbotron-fluid">
    <div class="row">
      <div class="col-md-1">
        <button type="button" id="generate-maze" class="btn btn-outline-primary">Generate</button>
      </div>
      <div class="col-md-2 padding-0">
        <div class="dropdown border-c float-r">
          <label for="rangeWallMaze">Wall</label>
          <input id="rangeWallMaze" class="border-c rangeMaze" type="range" min=3 max=10 step=1 value=3> 
        </div>
      </div>
      <div class="col-md-2 padding-0">
        <div class="dropdown border-c float-r">
          <label for="rangeTunnelMaze">Tunnel</label>
          <input id="rangeTunnelMaze" class="border-c rangeMaze" type="range" min="10" max="50" step="2" value="10"> 
        </div>
      </div>

      <div class="col-md-2">

        <div class="dropdown">
          <div class="input-group">
            <div class="input-group-prepend">
              <span class="input-group-text">x:y</span>
            </div>
              <input id="inputRowsMaze" type="number" class="form-control" value=10>
              <input id="inputColsMaze" type="number" class="form-control" value=10>
          </div>
        </div>

      </div>

      <div class="col-md-3 padding-0">

        <div class="dropdown">
          <div class="input-group h-34">
            <div class="input-group-prepend">
              <label class="input-group-text" for="inputWallColor">Wall</label>
            </div>
            <select class="color-select" id="inputWallColor">
              <option value="black" style="color: black">Black</option>
              <option value="white" style="color: black">White</option>
              <option value="red" style="color: red">Red</option>
              <option value="crimson" style="color: crimson">Crimson</option>
              <option value="brown" style="color: brown">Brown</option>
              <option value="green" style="color: green">Green</option>
              <option value="blue" style="color: blue">Blue</option>
              <option value="blueviolet" style="color: blueviolet">Blueviolet</option>
              <option value="magenta" style="color: magenta">Magenta</option>
              <option value="deeppink" style="color: deeppink">Deeppink</option>
              <option value="darkred" style="color: darkred">Darkred</option>
              <option value="indigo" style="color: indigo">Indigo</option>
            </select>
          </div>
        </div>

        <div class="dropdown">
          <div class="input-group h-34">
            <div class="input-group-prepend">
              <label class="input-group-text" for="inputBgColor">Bg</label>
            </div>
            <select class="color-select" id="inputBgColor">
              <option value="white" style="color: black">white</option>
              <option value="snow" style="background: snow">snow</option>
              <option value="honeydew" style="background: honeydew">honeydew</option>
              <option value="mintcream" style="background: mintcream">mintcream</option>
              <option value="azure" style="background: azure">azure</option>
              <option value="aliceblue" style="background: aliceblue">aliceblue</option>
              <option value="ghostwhite" style="background: ghostwhite">ghostwhite</option>
              <option value="whitesmoke" style="background: whitesmoke">whitesmoke</option>
              <option value="seashell" style="background: seashell">seashell</option>
              <option value="beige" style="background: beige">beige</option>
              <option value="oldlace" style="background: oldlace">oldlace</option>
              <option value="floralwhite" style="background: floralwhite">floralwhite</option>
              <option value="ivory" style="background: ivory">ivory</option>
              <option value="antiquewhite" style="background: antiquewhite">antiquewhite</option>
              <option value="linen" style="background: linen">linen</option>
              <option value="lavenderblush" style="background: lavenderblush">lavenderblush</option>
              <option value="mistyrose" style="background: mistyrose">mistyrose</option>
            </select>
          </div>
        </div>

      </div>

      <div class="col-md-1">
        <div class="dropdown">
          <div class="input-group h-34">
            <div class="input-group-prepend">
              
            </div>
            <select class="color-select" id="inputPoint">
              <option value="center">Center</option>
              <option value="left-top">Left-top</option>
              <option value="left-bottom">Left-bottom</option>
              <option value="right">Right</option>
            </select>
          </div>
        </div>
      </div>

    </div>
  </div>
  
  <div id="result-content" class="container margin-0">
    <div class="row">
      <div class="col-md-12 offset-0 center-h">
        <p id="res"></p>
          
          <canvas id="maze-canvas"></canvas>
        </div>
      </div>
    </div>
  </div>

</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/arudamanov/domains/neironica.com/public_html/tools/resources/views/texttools/maze.blade.php ENDPATH**/ ?>