<?php echo e($slot); ?>

<?php /**PATH /home/mac4r/projects-php/www/neironica/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>