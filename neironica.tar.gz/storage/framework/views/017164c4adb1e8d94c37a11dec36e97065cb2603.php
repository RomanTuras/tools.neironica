<?php $__env->startSection('content'); ?>

<section id="shulte-table">
  <div class="container">
    <h3 class="tools-title border-c">Таблица Шульте</h3>
  </div>
  <div class="jumbotron jumbotron-fluid">
    <div class="row">
      <div class="col-md-1">
        <button type="button" id="generate-shulte" class="btn btn-outline-primary">Generate</button>
      </div>
      <div class="col-md-2">
        <div class="dropdown paddingRange border-c float-r">
          
          <input id="paddingRangeShulte" class="border-c" type="range" min="5" max="25" step="1" value="17"> 
        </div>
      </div>
      <div class="col-md-2">
        <div class="dropdown">
          <div class="input-group">
            <div class="input-group-prepend">
              <label class="input-group-text" for="inputRowsShulte">Table</label>
            </div>
            <select class="rows-select" id="inputRowsShulte">
              <option value="4">4</option>
              <option value="5">5</option>
              <option value="6">6</option>
              <option value="7">7</option>
              <option value="8">8</option>
              <option value="9">9</option>
              <option value="10">10</option>
              <option value="11">11</option>
              <option value="12">12</option>
              <option value="13">13</option>
              <option value="14">14</option>
              <option value="15">15</option>
              <option value="16">16</option>
            </select>
          </div>
        </div>

        <div class="dropdown">
          <div class="input-group">
            <div class="input-group-prepend">
              <label class="input-group-text" for="inputColsShulte">:</label>
            </div>
            <select class="rows-select" id="inputColsShulte">
                <option value="4">4</option>
                <option value="5">5</option>
                <option value="6">6</option>
                <option value="7">7</option>
                <option value="8">8</option>
                <option value="9">9</option>
                <option value="10">10</option>
                <option value="11">11</option>
                <option value="12">12</option>
                <option value="13">13</option>
                <option value="14">14</option>
                <option value="15">15</option>
                <option value="16">16</option>
            </select>
          </div>
        </div>
      </div>

      <div class="col-md-3">
        <div class="dropdown">
          <div class="input-group">
            <div class="input-group-prepend">
              <label class="input-group-text" for="inputBgImage">Bg:</label>
            </div>
            <select class="image-select" id="inputBgImage">
              <option value="">No image</option>
              <option value="../img/@2x/blue_bubbels.jpg">Blue bubbles</option>
            </select>
          </div>
        </div>

        <div class="dropdown">
          <div class="dropdown">
            <div class="input-group h-34">
              <select class="font-select" id="inputColorSchema">
                <option value="no">No theme</option>
                <option value="#ec4061,#db5fe8,#6495ed,transparent,#9acd32,#f5de60">Monokai</option>
              </select>
            </div>
          </div>
        </div>
      </div>

      <div class="col-md-3 padding-0">
        <div class="dropdown">
          <div class="input-group h-34">
            <div class="input-group-prepend">
              
            </div>
            <select class="font-select" id="inputFontNameShulte">
              <option value="Arial">Arial</option>
              <option value="Times new Roman">Times new Roman</option>
              <option value="Roboto">Roboto</option>
              <option value="Courier New">Courier New</option>
              <option value="Impact">Impact</option> 
              <option value="Comic Sans MS">Comic Sans MS</option>
            </select>
          </div>
        </div>

        <div class="dropdown">
          <div class="input-group h-34">
            <div class="input-group-prepend">
              
            </div>
            <select class="font-select" id="inputFontSizeShulte">
              <option value="10">10</option>
              <option value="12">12</option>
              <option value="14">14</option>
              <option value="18">18</option>
              <option value="22">22</option>
              <option value="26">26</option>
              <option value="28">28</option>
              <option value="36">36</option>
              <option value="42">42</option>
              <option value="48">48</option>
              <option value="50">50</option>
              <option value="56">56</option>
              <option value="60">60</option>
              <option value="72">72</option>
            </select>
          </div>
        </div>
 
        <div class="dropdown">
          <div class="input-group h-34">
            <div class="input-group-prepend">
              
            </div>
            <select class="color-select" id="inputFontColorShulte">
              <option value="black" style="color: black">Black</option>
              <option value="white" style="color: black">White</option>
              <option value="red" style="color: red">Red</option>
              <option value="crimson" style="color: crimson">Crimson</option>
              <option value="brown" style="color: brown">Brown</option>
              <option value="green" style="color: green">Green</option>
              <option value="blue" style="color: blue">Blue</option>
              <option value="blueviolet" style="color: blueviolet">Blueviolet</option>
              <option value="magenta" style="color: magenta">Magenta</option>
              <option value="deeppink" style="color: deeppink">Deeppink</option>
              <option value="darkred" style="color: darkred">Darkred</option>
              <option value="indigo" style="color: indigo">Indigo</option>
            </select>
          </div>
        </div>                                      
      </div>

      <div class="col-md-1">
        <div class="dropdown">
          <label class="form-check-label border-c">
            <input id="checkboxBoldShulte" type="checkbox" class="form-check-input" value="">Bold
          </label>
        </div>
      </div>

      
    </div>
  </div>
  
  <div id="result-content" class="container">
    <div class="row">
      <div class="col-md-8 offset-2">
        <div id="result"></div>
      </div>
    </div>
  </div>

</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mac4r/projects-php/www/neironica/resources/views/texttools/shulte.blade.php ENDPATH**/ ?>