/**
 * Main function of "Math Examples"
 * Starting only when "math-examples" template is attached
 * Depends from classes:
 * - RandomizeHelper.js
 */
$(function () {
    if ($("#math-examples").length) {

        function startMathExamples() {
            let settingsMathExamplesObject = { //default settings for "math-examples"
                'fontName': 'Arial',
                'fontSize': 18,
            };
            const keyMathExamples = "math-examples";

            /**
             * Setting controls from local storage or by default
             */
            function setupControlsMathExamples() {
                if (LocalStorageHelper.getFontSettings(keyMathExamples) != null) {
                    settingsMathExamplesObject.fontName = LocalStorageHelper.getFontSettings(keyMathExamples).fontName;
                    settingsMathExamplesObject.fontSize = LocalStorageHelper.getFontSettings(keyMathExamples).fontSize;
                }
                $("#inputFontNameMath").val(settingsMathExamplesObject.fontName);
                $("#inputFontSizeMath").val(settingsMathExamplesObject.fontSize);
            }
            setupControlsMathExamples();

            //assign id's of the elements
            const inputOperation = "#inputOperation";
            const inputFirstNumberType = "#inputFirstNumberType";
            const inputSecondNumberType = "#inputSecondNumberType";
            const inputColumnsNumber = "#inputColumnsNumber";
            const inputExamplesNumber = "#inputExamplesNumber";
            const inputTextColor = "#inputTextColor";
            const inputFontSizeMath = "#inputFontSizeMath";
            const inputFontNameMath = "#inputFontNameMath";
            const paddingRangeMath = "#paddingRangeMath";
            const start = "#generate-math-examples";
            const checkBox = "#checkboxBoldMath";

            //values of the controls
            let operation = $(inputOperation).val();
            let firstNumberRange = $(inputFirstNumberType).val().split(','); //range for first number
            let secondNumberRange= $(inputSecondNumberType).val().split(','); //range for second number
            let columnsNumber = $(inputColumnsNumber).val();
            let examplesNumber = $(inputExamplesNumber).val();
            let fontColor = $(inputTextColor).val();
            let fontSize = $(inputFontSizeMath).val();
            let fontName = $(inputFontNameMath).val();
            let padding = $(paddingRangeMath).val();
            let resultList = [];
            let isFontBold = false;
            if ($(checkBox).prop("checked") === true){
                $("th").css("font-weight", "bold");
                isFontBold = true;
            }else{
                $("th").css("font-weight", "normal");
                isFontBold = false;
            }

            //events of controls
            $(inputOperation).change(function () {
                operation = this.value;
            });
            $(inputFirstNumberType).change(function () {
                firstNumberRange = this.value.split(',');
                console.log(firstNumberRange[0], firstNumberRange[1]);
            });
            $(inputSecondNumberType).change(function () {
                secondNumberRange = this.value.split(',');
            });
            $(inputColumnsNumber).change(function () {
                columnsNumber = this.value;
            });
            $(inputExamplesNumber).change(function () {
                examplesNumber = this.value;
            });
            $(inputTextColor).change(function () {
                fontColor = this.value;
                $("th").css("color", fontColor);
            });
            $(paddingRangeMath).change(function () {
                padding = this.value;
                $("th").css({
                    "padding-left": padding + "rem",
                    "padding-right": padding + "rem"
                });
            });
            $(inputFontSizeMath).on('change', function(){
                fontSize = this.value;
                $("th").css("font-size", fontSize + "px");
                settingsMathExamplesObject.fontSize = fontSize;
                LocalStorageHelper.saveFontSettings(keyMathExamples, settingsMathExamplesObject);
            });
            $(inputFontNameMath).on('change', function(){
                fontName = this.value;
                $("th").css("font-family", fontName);
                settingsMathExamplesObject.fontName = fontName;
                LocalStorageHelper.saveFontSettings(keyMathExamples, settingsMathExamplesObject);
            });
            $(checkBox).change(function () {
                if ($(checkBox).prop("checked") === true){
                    $("th").css("font-weight", "bold");
                    isFontBold = true;
                }else{
                    $("th").css("font-weight", "normal");
                    isFontBold = false;
                }
            });


            /**
             * Generate a new math examples
             */
            $(start).click(function () {
                let totalExamples = parseInt(examplesNumber) * parseInt(columnsNumber);
                resultList = getListExamples(operation, totalExamples, firstNumberRange, secondNumberRange);
                showTable(resultList, columnsNumber, examplesNumber);
                styleTable(fontName, fontSize, fontColor, padding, isFontBold);
            })
        }
        startMathExamples();


        /**
         * Stylable table
         * @param fontName - String
         * @param fontSize - Integer
         * @param fontColor - String
         * @param padding - Integer
         * @param isFontBold - boolean
         */
        function styleTable(fontName, fontSize, fontColor, padding, isFontBold) {
            $("th").css({
                "font-family": fontName,
                "font-size": fontSize + "px",
                "color": fontColor,
                "font-weight": isFontBold?"bold":"normal",
                "padding-left": padding + "rem",
                "padding-right": padding + "rem"
            });
        }

        /**
         * Showing a table with math examples
         * @param resultList - Array of math examiles
         * @param columnsNumber - Integer
         * @param examplesNumber - Integer
         */
        function showTable(resultList, columnsNumber, examplesNumber) {
            const result = "#res";
            let table = '<table id="table-math-examples" class="table table-striped">';
            table += '<tbody>';
            let i = 0;
            for (let example=0; example<examplesNumber; example++){
                table += '<tr>';
                for (let column=0; column<columnsNumber; column++){
                    table += `<th class="cell-math">${resultList[i]}</th>`;
                    i++;
                }
                table += '</tr>';
            }
            table += '</tbody></table>'
            $(result).html(table);
        }

        /**
         * Getting filled array of examples, depends from operations
         * @param operation - String, math operator
         * @param totalExamples - Integer, numbers of examples
         * @param firstNumberRange - Array, range of min and max numbers in examples
         * @param secondNumberRange - Array, range of min and max numbers in examples
         * @returns {[]} - Array
         */
        function getListExamples(operation, totalExamples, firstNumberRange, secondNumberRange) {
            let resultList = [];
            switch (operation) {
                case 'plus':
                    resultList = getListOfPlusOperation(firstNumberRange, secondNumberRange, totalExamples);
                    break;
                case 'minus':
                    break;
                case 'multiply':
                    break;
                case 'split':
                    break;
            }
            return resultList;
        }

        /**
         * Getting filled array of examples by PLUS operation
         * @param firstNumberRange - Array, range of min and max numbers in examples
         * @param secondNumberRange - Array, range of min and max numbers in examples
         * @param totalExamples - Integer, numbers of examples
         * @returns {[]} - Array
         */
        function getListOfPlusOperation(firstNumberRange, secondNumberRange, totalExamples) {
            let resultList = [];
            let firstNumber = 0;
            let secondNumber = 0;
            for (let i=0; i<totalExamples; i++){
                firstNumber = RandomizeHelper.getRandomInt(firstNumberRange[0], firstNumberRange[1]);
                secondNumber = RandomizeHelper.getRandomInt(secondNumberRange[0], secondNumberRange[1]);
                resultList.push(`${firstNumber} + ${secondNumber}`);
            }
            return resultList;
        }


    }
});
